﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CreditCalculator
{
    class Calculator
    {
        static void Main()
        {
            
            string quit = "1";
            while (quit != "0")
            {
                Account acct = new Account();
                Console.WriteLine("Enter your Account Number");
                acct.accNum = Console.ReadLine();

                Console.WriteLine("Enter your Starting Balance");
                acct.startBal = Convert.ToDecimal(Console.ReadLine());

                Console.WriteLine("Enter your Charges");
                acct.charges = Convert.ToDecimal(Console.ReadLine());

                Console.WriteLine("Enter your Credit");
                acct.credit = Convert.ToDecimal(Console.ReadLine());

                Console.WriteLine("Enter your Credit Limit");
                acct.creditLimit = Convert.ToDecimal(Console.ReadLine());

                if (acct.NewBal() > acct.creditLimit)
                {
                    Console.WriteLine("You have exceeded your credit limit!");
                }
                else
                {
                    Console.WriteLine($"Your current balance is {0:F2}", acct.NewBal());
                    Console.WriteLine($"Available credit is {0:F2}", (acct.creditLimit - acct.NewBal()));
                }


                Console.WriteLine("Do you want to continue? Enter 0 to quit!");


                quit = Console.ReadLine();
            }
            Console.ReadLine();
        }
    }

    
    class Account
    {
        public string accNum;
        public decimal startBal;
        public decimal charges;
        public decimal credit;
        public decimal creditLimit;

        public decimal NewBal()
        {

            return (startBal + charges - credit);

        }
    
    }
}
